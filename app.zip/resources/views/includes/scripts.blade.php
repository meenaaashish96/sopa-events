<!-- EXTERNAL SCRIPTS
		============================================= -->	
		<script src="https://code.jquery.com/jquery-3.6.0.js"></script>
		<script src="{{ url('/ui/js/bootstrap.min.js')}}"></script>	
		<script src="{{ url('/ui/js/modernizr.custom.js')}}"></script>
		<script src="{{ url('/ui/js/jquery.easing.js')}}"></script>
		<script src="{{ url('/ui/js/jquery.appear.js')}}"></script>
		<!-- <script src="js/jquery.stellar.min.js"></script>	 -->
		<!-- <script src="js/menu.js"></script> -->
		<script src="{{ url('/ui/js/slick.min.js')}}"></script>
		<script src="{{ url('/ui/js/jquery.countdown.min.js')}}"></script>	
		<script src="{{ url('/ui/js/jquery.scrollto.js')}}"></script>
		<script src="{{ url('/ui/js/owl.carousel.min.js')}}"></script>
		<script src="{{ url('/ui/js/jquery.magnific-popup.min.js')}}"></script>	
		<script src="{{ url('/ui/js/imagesloaded.pkgd.min.js')}}"></script>
		<script src="{{ url('/ui/js/isotope.pkgd.min.js')}}"></script>
		<!-- <script src="js/register-form.js"></script> -->
		{{-- <script src="{{ url('/ui/js/contact-form.js')}}"></script>	 --}}
		<script src="{{ url('/ui/js/jquery.ajaxchimp.min.js')}}"></script>	
		<script src="{{ url('/ui/js/jquery.validate.min.js')}}"></script>	
	
		<!-- Custom Script -->		
		<script src="{{ url('/ui/js/custom.js')}}"></script>
